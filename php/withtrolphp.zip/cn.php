<?php
$conexion = mysqli_connect("localhost", "root", "", "withtrol");
//$conexion = mysqli_connect("localhost", "root", "", "ottos_26178584_maindb");
if (!$conexion) {
    echo 'error';
}



?>