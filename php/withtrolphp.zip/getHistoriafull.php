<?php

$query = $_POST['date'];

$data = file_get_contents("../json/clasespasadas.json");
$a = json_decode($data, true);
$products = array_reverse($a);

$contador = 0;

if ($query === "") {
    foreach ($products as $product) {
                echo '<tr><th scope="row"><img width="30px" src="media/library-outline.svg" alt=""></th> <td>'; 
                print_r($product['cod']);
                echo '</td>
                <td>';
                print_r($product['nota']);
                echo '</td>
                <td>'; 
                print_r($product['periodo']);
                echo '</td>
            </tr>';
            $contador += 1;
    }
}else {
    foreach ($products as $product) {
        if (strpos($product['periodo'], $query) !== false) {
            echo '<tr><th scope="row"><img width="30px" src="media/library-outline.svg" alt=""></th> <td>'; 
            print_r($product['cod']);
            echo '</td>
            <td>';
            print_r($product['nota']);
            echo '</td>
            <td>'; 
            print_r($product['periodo']);
            echo '</td>
        </tr>';
        $contador += 1;
        }
}
}

if ($contador == 0) {
    # code...
    echo 'Sin Resultados';
}
   
?>