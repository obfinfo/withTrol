<?php

$datos = file_get_contents('../json/datos.json');
$datos3 =  json_decode($datos, true);
        echo $datos3['ultimoperiodo'];