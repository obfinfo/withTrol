<?php
 
 $sumaclasesmulti=0;
 $notaclasetemp=0;
 $sumauv=0;

 $file = file_get_contents("../json/clasespasadas.json");
 $b = json_decode($file, true);

 foreach ($b as $product) {
    $notaclasetemp = $product['nota'] * $product['uv'];
    $sumaclasesmulti += $notaclasetemp;
    $sumauv += $product['uv'];
   }
    $calcul =$sumaclasesmulti / $sumauv;
    $promedio = "<h1 class='promedio up'>". (int)$calcul."%</h1>";
    echo $promedio;
?> 