<?php
 $data = file_get_contents("../json/datos.json");
 $a = json_decode($data, true);
 $periodo =$a['ultimoperiodo'];
 
 $sumaclasesmulti=0;
 $notaclasetemp=0;
 $sumauv=0;

 $file = file_get_contents("../json/clasespasadas.json");
 $b = json_decode($file, true);

 foreach ($b as $product) {
   if ($product['periodo'] == $periodo) {
    $notaclasetemp = $product['nota'] * $product['uv'];
    $sumaclasesmulti += $notaclasetemp;
    $sumauv += $product['uv'];
   }
    }
    $calcul = $sumaclasesmulti / $sumauv;
    $promedio = "<h1>". (int)$calcul."%</h1>";
    echo $promedio;
?> 