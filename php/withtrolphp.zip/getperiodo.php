<?php

$data = file_get_contents("../json/datos.json");
 $a = json_decode($data, true);
 $periodo =$a['ultimoperiodo'];
 
 
 echo $periodo;