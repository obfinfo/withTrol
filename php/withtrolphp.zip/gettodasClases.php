<?php

$data = file_get_contents("../json/clases.json");
$products = json_decode($data, true);

foreach ($products as $product) {
        print_r($product['codigo']);
        print_r($product['nombre']);
        print_r($product['uv']);
    
}