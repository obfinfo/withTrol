<?php
$codigovar = "IN101";
$file3 = file_get_contents('..\json\clasesrestantes.json');
$filee4 =  json_decode($file3, true);


print_r($filee4);
echo'<br/>';
$array;
$i =0;
foreach ($filee4 as $array) {
    if ($array['codigo'] == $codigovar) {
        unset($filee4[$i]);
        echo'borrado';
    }
    if ($array["requisitos"]["0"] == $codigovar ) {
        $filee4[$i]["requisitos"]["0"]="";
    }
    print_r($array['codigo']);
    echo'<br/>';
    $i += 1;
}
echo'<br/>';
print_r($filee4);